Datasource: https://cs.nyu.edu/~kcho/DMQA/

Instruction for execution: This zip file contains .ipnb file named (DL_Final_1883.ipynb) please execute it one cell after another. Colab is prefered as weextract our datafile from google dirve.
-> The colab file also contains some installations of essential libraries that are commented out. please execute them by removing the #.

